// Chart data
export interface Payment {
    COMPANY_ID?: any;
    USER_ID?: any;
    USER_TYPE?: any;
}
