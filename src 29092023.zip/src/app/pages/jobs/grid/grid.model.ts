export interface jobGridModel {
    id: any;
    image: string;
    title: string;
    year: string;
    company: string;
    location: any;
    price: any;
  }
  