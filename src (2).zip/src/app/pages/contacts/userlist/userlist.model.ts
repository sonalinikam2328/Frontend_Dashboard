export interface userListModel {
  profile?: string;
  name: string;
  position: string;
  email: string;
  tags: Array<{}>;
  project: string;
  isSelected?:any;
}
  