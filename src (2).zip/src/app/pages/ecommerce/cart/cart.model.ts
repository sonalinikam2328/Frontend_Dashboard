export interface Cart {
    id: any;
    image: string;
    name: string;
    color: string;
    price: string;
    quantity: number;
    total: string;
}
